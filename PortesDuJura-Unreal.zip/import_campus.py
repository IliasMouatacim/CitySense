"""Run in the Unreal Editor Python console from a First Person project."""

import math
import os

import unreal

ASSET_FOLDER = "/Game/PortesDuJura/Imported"
LEVEL = "/Game/PortesDuJura/PortesDuJura"
START_MARKER = "Campus_Start_Marker"
VIEW_MARKER = "Campus_View_Marker"
# These include the measured terrain, accessible roofs, stair treads, wall
# volumes, curbs and the concrete projections in the existing campus scene.
SOLID_BATCHES = (
    "Campus_Terrain", "Courtyard_Paving", "Building_Walls", "Architectural_Details",
    "Campus_Concrete", "Campus_Roofs", "Metalwork", "Asphalt", "Paving", "Lawns",
    "Sand", "Timber", "Roofs",
)


def import_campus(glb_path, game_mode_path=None):
    """Import campus assets and create a new map. Keep this map open for Play."""
    if not os.path.isfile(glb_path):
        raise FileNotFoundError(glb_path)
    assets = unreal.get_editor_subsystem(unreal.EditorAssetSubsystem)
    levels = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)

    if assets.does_asset_exist(LEVEL) or assets.does_directory_exist(ASSET_FOLDER):
        raise RuntimeError("The PortesDuJura content folder already exists. Use a fresh project or move the previous import.")

    game_mode_path = game_mode_path or "/Game/FirstPerson/Blueprints/BP_FirstPersonGameMode"
    game_mode = assets.load_blueprint_class(game_mode_path)
    if not game_mode:
        raise RuntimeError("Use an Unreal First Person project or provide its GameMode Blueprint asset path.")

    task = unreal.AssetImportTask()
    task.set_editor_property("filename", os.path.abspath(glb_path))
    task.set_editor_property("destination_path", ASSET_FOLDER)
    task.set_editor_property("automated", True)
    task.set_editor_property("save", False)
    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
    meshes = [item for item in task.get_objects() if isinstance(item, unreal.StaticMesh)]

    def find_marker(name):
        matches = [mesh for mesh in meshes if name in mesh.get_name()]
        if len(matches) != 1:
            raise RuntimeError(f"Expected one mesh for {name}. Import separate glTF meshes with baked vertices.")
        return matches[0]

    start_marker = find_marker(START_MARKER)
    view_marker = find_marker(VIEW_MARKER)
    start = start_marker.get_bounds().origin
    target = view_marker.get_bounds().origin
    heading = target - start
    if not math.isclose(math.hypot(heading.x, heading.y), 200.0, abs_tol=2.0) or abs(heading.z) > 2.0:
        raise RuntimeError("Expected a horizontal 200 cm gap between the import markers. Check importer units and axes.")

    if not levels.new_level(LEVEL):
        raise RuntimeError(f"Couldn't create {LEVEL}")
    actor_type = unreal.StaticMeshActor
    for mesh in meshes:
        if mesh in (start_marker, view_marker):
            continue
        name = mesh.get_name()
        actor = actors.spawn_actor_from_class(actor_type, unreal.Vector())
        actor.set_actor_label(name)
        component = actor.get_editor_property("static_mesh_component")
        component.set_static_mesh(mesh)
        solid = any(batch in name for batch in SOLID_BATCHES)
        if solid:
            body = mesh.get_editor_property("body_setup")
            body.set_editor_property("collision_trace_flag", unreal.CollisionTraceFlag.CTF_USE_COMPLEX_AS_SIMPLE)
        component.set_collision_profile_name("BlockAll" if solid else "NoCollision")

    yaw = math.degrees(math.atan2(heading.y, heading.x))
    player = actors.spawn_actor_from_class(
        unreal.PlayerStart, start + unreal.Vector(0, 0, 110), unreal.Rotator(pitch=0, yaw=yaw, roll=0)
    )
    player.set_actor_label("Bâtiment B Walkthrough Start")
    unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world().get_world_settings().set_editor_property(
        "default_game_mode", game_mode
    )
    sun = actors.spawn_actor_from_class(unreal.DirectionalLight, unreal.Vector(), unreal.Rotator(pitch=-45, yaw=-30, roll=0))
    sun.set_actor_label("Campus Sun")
    sun.get_editor_property("light_component").set_editor_property("atmosphere_sun_light", True)
    actors.spawn_actor_from_class(unreal.SkyAtmosphere, unreal.Vector())
    sky = actors.spawn_actor_from_class(unreal.SkyLight, unreal.Vector())
    sky.get_editor_property("light_component").set_editor_property("real_time_capture", True)

    assets.save_directory(ASSET_FOLDER)
    if not levels.save_current_level():
        raise RuntimeError(f"Couldn't save {LEVEL}")
    unreal.log(f"Imported {len(meshes) - 2} campus meshes into {LEVEL}. Press Play to start near Bâtiment B.")


if __name__ == "__main__":
    import sys

    if len(sys.argv) not in (2, 3):
        raise RuntimeError("Pass the GLB path and, optionally, a First Person GameMode Blueprint asset path.")
    import_campus(*sys.argv[1:])
