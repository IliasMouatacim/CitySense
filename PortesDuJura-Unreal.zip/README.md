# Portes du Jura in Unreal Engine

## Open the campus

1. Create an Unreal Engine 5 First Person project with the standard Blueprint template. Enable **Python Editor Script Plugin** and **Interchange Editor** if needed, then restart Unreal. Leave the project open in the editor.
2. Put `PortesDuJura.glb` and `import_campus.py` on your machine. In Unreal's Output Log, switch the command field to **Python** and run the line below with your local paths. Use forward slashes on Windows.
3. The script creates `/Game/PortesDuJura/PortesDuJura` and opens it. Press **Play** and use the First Person template controls. Start near Bâtiment B and walk towards the courtyard, the library passage, and the CROUS.

```python
import runpy; runpy.run_path(r"C:/CitySense/import_campus.py")["import_campus"](r"C:/CitySense/PortesDuJura.glb")
```

If your template uses a different GameMode, pass its Blueprint asset path as the second argument to `import_campus`. The script expects an empty `/Game/PortesDuJura` import destination. Check Unreal's import log if Interchange skips meshes. Keep the meshes separate and use the default glTF scale. The importer checks the two exported marker meshes before using them to set the start position and heading.

## Regenerate the GLB

From the CitySense repository root with workspace dependencies installed, run:

```sh
pnpm exec playwright install chromium
node scripts/export-unreal-campus.mjs
```

Set `CAMPUS_CHROMIUM` to use a compatible system Chromium executable. Pass a path as the last argument to change the output from `.data/PortesDuJura.glb`.

The export uses the campus terrain patch, available campus building volumes and registered façades, paved surfaces, street furniture, planted areas, and signage. Meshes use meters and a shared origin near the Bâtiment B start. The GLB embeds the textures. Three.js shader effects such as courtyard stone courses, bump maps, and environmental lighting need Unreal material and lighting work for visual parity. The importer uses triangle collision on solid batches and leaves glass, signs, and foliage free of collision. Verify stairs and passages in the target Unreal version before distributing a build.

Source data includes IGN BD TOPO / RGE ALTI and OpenStreetMap contributors (ODbL). Keep the project's source credits when redistributing the campus.
